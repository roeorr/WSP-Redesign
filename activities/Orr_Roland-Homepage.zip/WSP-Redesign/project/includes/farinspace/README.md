[jQuery Image Preload Plugin][imgpreload]
=========================

The jQuery imgpreload plugin allows you to preload images before and/or after the DOM is loaded.

[imgpreload]: http://farinspace.com/2009/05/jquery-image-preload-plugin/ "jQuery Image Preload Plugin"